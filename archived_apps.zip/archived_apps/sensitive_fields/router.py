"""
API router for sensitive field configuration management.
"""

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.logging import get_logger
from src.db.session import get_db_with_trace_id
from src.core.pagination import PageParams, PaginatedResponse
from src.core.schemas import APIResponse
from src.middleware.trace import get_trace_id
from src.apps.sensitive_fields.repository import SensitiveFieldRepository
from src.apps.sensitive_fields.schemas import (
    SensitiveFieldCreate,
    SensitiveFieldResponse,
    SensitiveFieldUpdate,
)
from src.apps.sensitive_fields.service import SensitiveFieldService


router = APIRouter()


def get_sensitive_field_service(
    db: AsyncSession = Depends(get_db_with_trace_id),
) -> SensitiveFieldService:
    """Get sensitive field service instance."""
    repository = SensitiveFieldRepository(db)
    return SensitiveFieldService(repository)


@router.post(
    "/",
    response_model=APIResponse[SensitiveFieldResponse],
    status_code=status.HTTP_201_CREATED,
)
async def create_sensitive_field(
    request: Request,
    sensitive_field: SensitiveFieldCreate,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Create a new sensitive field pattern."""
    logger = get_logger(request)
    logger.info(f"Creating sensitive field pattern: {sensitive_field.field_name}")

    result = await service.create_sensitive_field(sensitive_field)

    if not result:
        raise HTTPException(
            status_code=400,
            detail=f"Sensitive field pattern '{sensitive_field.field_name}' already exists",
        )

    logger.info(f"Sensitive field pattern created successfully: {result.id}")
    return APIResponse.create_with_trace_id(
        data=result,
        message="Sensitive field pattern created successfully",
        status_code=201,
        trace_id=get_trace_id(request),
    )


@router.get("/", response_model=APIResponse[PaginatedResponse[SensitiveFieldResponse]])
async def list_sensitive_fields(
    request: Request,
    params: PageParams = Depends(),
    search: Optional[str] = Query(
        None, description="Search term for field name or description"
    ),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """List sensitive field patterns with pagination and filtering."""
    logger = get_logger(request)
    logger.info(
        f"Listing sensitive fields: skip={params.skip}, limit={params.limit}, "
        f"search={search}, is_active={is_active}"
    )

    items, total = await service.get_all_sensitive_fields(
        params.skip, params.limit, search, is_active
    )

    paginated_response = PaginatedResponse.create(
        items=items,
        total=total,
        params=params,
    )

    return APIResponse.create_with_trace_id(
        data=paginated_response,
        message="Sensitive field patterns retrieved successfully",
        status_code=200,
        trace_id=get_trace_id(request),
    )


@router.get("/active", response_model=APIResponse[list[dict]])
async def get_active_sensitive_fields(
    request: Request,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Get all active sensitive field patterns for masking logic."""
    logger = get_logger(request)
    logger.info("Getting active sensitive field patterns")

    result = await service.get_active_sensitive_fields()
    return APIResponse.create_with_trace_id(
        data=result,
        message="Active sensitive field patterns retrieved successfully",
        status_code=200,
        trace_id=get_trace_id(request),
    )


@router.get("/{sensitive_field_id}", response_model=APIResponse[SensitiveFieldResponse])
async def get_sensitive_field(
    request: Request,
    sensitive_field_id: UUID,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Get a sensitive field pattern by ID."""
    logger = get_logger(request)
    logger.info(f"Getting sensitive field pattern: {sensitive_field_id}")

    result = await service.get_sensitive_field(sensitive_field_id)

    if not result:
        raise HTTPException(status_code=404, detail="Sensitive field pattern not found")

    return APIResponse.create_with_trace_id(
        data=result,
        message="Sensitive field pattern retrieved successfully",
        status_code=200,
        trace_id=get_trace_id(request),
    )


@router.put("/{sensitive_field_id}", response_model=APIResponse[SensitiveFieldResponse])
async def update_sensitive_field(
    request: Request,
    sensitive_field_id: UUID,
    sensitive_field: SensitiveFieldUpdate,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Update a sensitive field pattern."""
    logger = get_logger(request)
    logger.info(f"Updating sensitive field pattern: {sensitive_field_id}")

    result = await service.update_sensitive_field(sensitive_field_id, sensitive_field)

    if not result:
        # We need to distinguish between not found and conflict, but service
        # returns None for both currently.
        # Ideally service should raise specific exceptions or return a status.
        raise HTTPException(
            status_code=404,
            detail=("Sensitive field pattern not found or already exists"),
        )

    logger.info(f"Sensitive field pattern updated successfully: {sensitive_field_id}")
    return APIResponse.create_with_trace_id(
        data=result,
        message="Sensitive field pattern updated successfully",
        status_code=200,
        trace_id=get_trace_id(request),
    )


@router.delete("/{sensitive_field_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_sensitive_field(
    request: Request,
    sensitive_field_id: UUID,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Delete a sensitive field pattern."""
    logger = get_logger(request)
    logger.info(f"Deleting sensitive field pattern: {sensitive_field_id}")

    success = await service.delete_sensitive_field(sensitive_field_id)

    if not success:
        raise HTTPException(status_code=404, detail="Sensitive field pattern not found")

    logger.info(f"Sensitive field pattern deleted successfully: {sensitive_field_id}")
    return None


@router.patch(
    "/{sensitive_field_id}/deactivate",
    response_model=APIResponse[SensitiveFieldResponse],
)
async def deactivate_sensitive_field(
    request: Request,
    sensitive_field_id: UUID,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Deactivate a sensitive field pattern (soft delete)."""
    logger = get_logger(request)
    logger.info(f"Deactivating sensitive field pattern: {sensitive_field_id}")

    result = await service.deactivate_sensitive_field(sensitive_field_id)

    if not result:
        raise HTTPException(status_code=404, detail="Sensitive field pattern not found")

    logger.info(
        f"Sensitive field pattern deactivated successfully: {sensitive_field_id}"
    )
    return APIResponse.create_with_trace_id(
        data=result,
        message="Sensitive field pattern deactivated successfully",
        status_code=200,
        trace_id=get_trace_id(request),
    )


@router.patch(
    "/{sensitive_field_id}/activate", response_model=APIResponse[SensitiveFieldResponse]
)
async def activate_sensitive_field(
    request: Request,
    sensitive_field_id: UUID,
    service: SensitiveFieldService = Depends(get_sensitive_field_service),
):
    """Activate a sensitive field pattern."""
    logger = get_logger(request)
    logger.info(f"Activating sensitive field pattern: {sensitive_field_id}")

    result = await service.activate_sensitive_field(sensitive_field_id)

    if not result:
        raise HTTPException(status_code=404, detail="Sensitive field pattern not found")

    logger.info(f"Sensitive field pattern activated successfully: {sensitive_field_id}")
    return APIResponse.create_with_trace_id(
        data=result,
        message="Sensitive field pattern activated successfully",
        status_code=200,
        trace_id=get_trace_id(request),
    )
