"""
Service layer for sensitive field configuration operations.
"""

from typing import List, Optional

from src.apps.sensitive_fields.repository import SensitiveFieldRepository
from src.apps.sensitive_fields.schemas import (
    SensitiveFieldCreate,
    SensitiveFieldUpdate,
)


class SensitiveFieldService:
    """Service for sensitive field configuration operations."""

    def __init__(self, repository: SensitiveFieldRepository):
        self.repository = repository

    async def create_sensitive_field(
        self, sensitive_field: SensitiveFieldCreate
    ) -> dict:
        """Create a new sensitive field pattern."""
        # Check if field name already exists
        existing = await self.repository.get_by_field_name(sensitive_field.field_name)
        if existing:
            return None

        return await self.repository.create(sensitive_field)

    async def get_sensitive_field(self, sensitive_field_id: int) -> dict:
        """Get a sensitive field pattern by ID."""
        return await self.repository.get_by_id(sensitive_field_id)

    async def get_all_sensitive_fields(
        self,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> tuple[List, int]:
        """Get all sensitive field patterns with pagination and filtering."""
        return await self.repository.get_all(skip, limit, search, is_active)

    async def get_active_sensitive_fields(self) -> List[dict]:
        """Get all active sensitive field patterns for masking logic."""
        db_sensitive_fields = await self.repository.get_all_active()
        return [
            {
                "field_name": field.field_name,
                "is_exact_match": field.is_exact_match,
                "description": field.description,
            }
            for field in db_sensitive_fields
        ]

    async def update_sensitive_field(
        self, sensitive_field_id: int, sensitive_field: SensitiveFieldUpdate
    ) -> dict:
        """Update a sensitive field pattern."""
        # Check if field name already exists (if being updated)
        if sensitive_field.field_name:
            existing = await self.repository.get_by_field_name(
                sensitive_field.field_name
            )
            if existing and existing.id != sensitive_field_id:
                return None

        return await self.repository.update(sensitive_field_id, sensitive_field)

    async def delete_sensitive_field(self, sensitive_field_id: int) -> bool:
        """Delete a sensitive field pattern."""
        return await self.repository.delete(sensitive_field_id)

    async def deactivate_sensitive_field(self, sensitive_field_id: int) -> dict:
        """Deactivate a sensitive field pattern (soft delete)."""
        return await self.repository.deactivate(sensitive_field_id)

    async def activate_sensitive_field(self, sensitive_field_id: int) -> dict:
        """Activate a sensitive field pattern."""
        return await self.repository.activate(sensitive_field_id)
