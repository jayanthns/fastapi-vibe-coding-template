from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession


class TestSensitiveFieldAPIs:
    """Test cases for sensitive field API endpoints."""

    async def test_create_sensitive_field(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test creating a new sensitive field pattern."""
        payload = {
            "field_name": "api_key",
            "is_exact_match": True,
            "is_active": True,
            "description": "API Key field",
        }

        response = client.post("/api/v1/sensitive-fields/", json=payload)
        data = response.json()

        assert response.status_code == 201
        assert data["success"] is True
        assert data["data"]["field_name"] == payload["field_name"]
        assert data["data"]["is_exact_match"] == payload["is_exact_match"]
        assert "id" in data["data"]

    async def test_create_duplicate_sensitive_field(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test creating a duplicate sensitive field pattern."""
        payload = {
            "field_name": "duplicate_key",
            "is_exact_match": True,
            "is_active": True,
        }

        # Create first time
        client.post("/api/v1/sensitive-fields/", json=payload)

        # Create second time
        response = client.post("/api/v1/sensitive-fields/", json=payload)
        data = response.json()

        assert response.status_code == 400
        assert data["success"] is False
        assert "already exists" in data["error"]

    async def test_list_sensitive_fields(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test listing sensitive field patterns with pagination."""
        # Create some fields
        for i in range(3):
            client.post(
                "/api/v1/sensitive-fields/",
                json={
                    "field_name": f"field_{i}",
                    "is_exact_match": True,
                    "is_active": True,
                },
            )

        response = client.get("/api/v1/sensitive-fields/")
        data = response.json()

        assert response.status_code == 200
        assert data["success"] is True
        assert "items" in data["data"]
        assert "total" in data["data"]
        assert len(data["data"]["items"]) >= 3

    async def test_get_sensitive_field(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test getting a sensitive field pattern by ID."""
        # Create a field
        create_response = client.post(
            "/api/v1/sensitive-fields/",
            json={
                "field_name": "get_test",
                "is_exact_match": True,
                "is_active": True,
            },
        )
        field_id = create_response.json()["data"]["id"]

        # Get the field
        response = client.get(f"/api/v1/sensitive-fields/{field_id}")
        data = response.json()

        assert response.status_code == 200
        assert data["success"] is True
        assert data["data"]["id"] == field_id
        assert data["data"]["field_name"] == "get_test"

    async def test_update_sensitive_field(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test updating a sensitive field pattern."""
        # Create a field
        create_response = client.post(
            "/api/v1/sensitive-fields/",
            json={
                "field_name": "update_test",
                "is_exact_match": True,
                "is_active": True,
            },
        )
        field_id = create_response.json()["data"]["id"]

        # Update the field
        update_payload = {"description": "Updated description", "is_active": False}
        response = client.put(
            f"/api/v1/sensitive-fields/{field_id}", json=update_payload
        )
        data = response.json()

        assert response.status_code == 200
        assert data["success"] is True
        assert data["data"]["description"] == "Updated description"
        assert data["data"]["is_active"] is False

    async def test_delete_sensitive_field(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test deleting a sensitive field pattern."""
        # Create a field
        create_response = client.post(
            "/api/v1/sensitive-fields/",
            json={
                "field_name": "delete_test",
                "is_exact_match": True,
                "is_active": True,
            },
        )
        field_id = create_response.json()["data"]["id"]

        # Delete the field
        response = client.delete(f"/api/v1/sensitive-fields/{field_id}")
        assert response.status_code == 204

        # Verify deletion
        get_response = client.get(f"/api/v1/sensitive-fields/{field_id}")
        assert get_response.status_code == 404

    async def test_get_active_sensitive_fields(
        self, async_session: AsyncSession, client: TestClient
    ):
        """Test getting active sensitive field patterns."""
        # Create active and inactive fields
        client.post(
            "/api/v1/sensitive-fields/",
            json={
                "field_name": "active_field",
                "is_exact_match": True,
                "is_active": True,
            },
        )
        client.post(
            "/api/v1/sensitive-fields/",
            json={
                "field_name": "inactive_field",
                "is_exact_match": True,
                "is_active": False,
            },
        )

        response = client.get("/api/v1/sensitive-fields/active")
        data = response.json()

        assert response.status_code == 200
        assert data["success"] is True

        # Check that active_field is present and inactive_field is not
        field_names = [item["field_name"] for item in data["data"]]
        assert "active_field" in field_names
        assert "inactive_field" not in field_names
